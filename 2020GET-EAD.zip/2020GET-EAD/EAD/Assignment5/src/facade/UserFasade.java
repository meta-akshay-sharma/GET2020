package facade;

public class UserFasade {

}
