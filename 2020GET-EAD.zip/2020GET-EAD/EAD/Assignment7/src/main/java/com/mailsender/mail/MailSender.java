package com.mailsender.mail;

public interface MailSender {
	void sendMail();
}
